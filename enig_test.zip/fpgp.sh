#!/bin/bash
sudo mkdir /home/.enigmail
sudo mkdir /home/.enigmail/keyDone
sudo mkdir /home/.enigmail/keyNotDone
sudo mkdir /home/.enigmail/key
sudo mkdir /home/.enigmail/notStarted

sudo apt-get install thunderbird
sudo apt-get install libwww-curl-perl

sudo echo "no" > /home/.enigmail/notStarted/notstarted.txt

sudo mv perl_fb.pl home/.enigmail/

sudo thunderbird