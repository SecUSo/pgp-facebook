#!/bin/bash
mkdir /home/.enigmail
mkdir /home/.enigmail/keyDone
mkdir /home/.enigmail/keyNotDone
mkdir /home/.enigmail/key
mkdir /home/.enigmail/notStarted

apt-get install thunderbird
apt-get install libwww-curl-perl

echo "no" > /home/.enigmail/notStarted/notstarted.txt

mv perl_fb.pl /home/.enigmail/

thunderbird