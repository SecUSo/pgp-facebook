# installieren Abhängigkeiten
sudo ./fpgp.sh

Addon-Manager --> Install Add-On from file
